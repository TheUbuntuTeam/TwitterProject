from setuptools import setup, find_packages

setup(
    name='extract_script',
    version='0.1',
    description='a script to extract tweet and save it to a database',
    author='UbuntuTeam',
    packages=find_packages(),
)
